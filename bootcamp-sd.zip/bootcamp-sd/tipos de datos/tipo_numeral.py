import math
# tipo de dato numeral; int, float

edad = 25   # tipo dato int()
ahorro = 55.5   # tipo float()
edad = 0

# print(edad)
# print(ahorro)

# print(edad + 5)
# edad = edad + 5
edad += 5
# print(edad)

# print(edad - 5)
# print(edad * 5)
# edad *= 5

print(ahorro / 2)
# print(ahorro // 2)
# ahorro = ahorro / 2
ahorro /= 2
print(int(ahorro))

print(math.trunc(57.9))
print(int(57.9))

print(round(75.9))


nuevo = int('123')
print(type(nuevo))
print(len('dojopy'))