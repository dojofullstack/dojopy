

# esto es un comentario
''' esto es un comentario de
    multiples lineas
    abc '''

username = 'Henry dojopy'
username = ''

print(username)

print(dir(username))

print(username.upper())
print(username.lower())
username = username.replace('dojo', 'academia')
print(username)

print(type(123))
conversion = str(123)
print(type(conversion))