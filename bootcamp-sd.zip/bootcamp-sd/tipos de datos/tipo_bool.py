
# tipo de dato booleano -> True, False



def mi_libreria(edad):
    # is_developer = True
    # print(type(is_developer))

    # other_var = []
    new_bool =  bool(edad)

    # if is_developer == 1:
    # print('es uno')

    # data = ['']
    # print(bool(data))
    return new_bool



def mi_libreria2():
    is_developer = True
    print(type(is_developer))

    other_var = []
    print(bool(other_var))

    # if is_developer == 1:
    # print('es uno')

    data = ['']
    print(bool(data))
    return True
