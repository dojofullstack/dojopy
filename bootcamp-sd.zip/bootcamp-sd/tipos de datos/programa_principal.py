from tipo_bool.mi_libreria import miModulo

edad = 0
new_var =  mi_libreria(edad)

print('mi variable es:', new_var)