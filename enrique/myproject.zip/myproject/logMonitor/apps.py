from django.apps import AppConfig


class LogmonitorConfig(AppConfig):
    name = 'logMonitor'
