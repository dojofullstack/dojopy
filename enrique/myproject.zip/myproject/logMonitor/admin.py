from django.contrib import admin
from .models import ModelLog
# Register your models here.

admin.site.register(ModelLog)
