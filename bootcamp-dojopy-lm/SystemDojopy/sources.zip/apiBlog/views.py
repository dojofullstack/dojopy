from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import *
from blog.models import *


class ApiListPost(APIView):
    def get(self, request):
        articles = BlogArticles.objects.all()
        data = SerializersPost(articles, many=True)
        return Response(data.data)


class GetPost(APIView):
    def get(self, request, id):
        # articles = BlogArticles.objects.get(id=id)
        article = get_object_or_404(BlogArticles, id=id)
        data = SerializersGetPost(article)
        return Response(data.data)


class FormContact(APIView):
    def post(self, request):
        # print(request.data)
        data = SerializersFormContact(data=request.data)
        is_data_valid = data.is_valid()
        if is_data_valid:
            contact = data.save()
            return Response({'id': contact.id, 'message': 'contact created'})
        else:
            errors = data.errors
            return Response({'message': 'data invalida validar los siguientes campos', 'fields': errors})




