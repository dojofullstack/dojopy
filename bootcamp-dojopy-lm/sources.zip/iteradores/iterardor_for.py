
""" se peude iterar sobre cualquier tipo de dato """

myarray = ['python', 'javascript']
myarray2 =  range(1, 10)

# new_list = []
# for item in myarray2:
#     if item % 2 == 0:
#         new_list.append(item)

# print(new_list)


# new_iterador = [
#                 item
#                 for item in range(1,10)
#                 if item == 9
#                 ]

# print(new_iterador)


# username = 'henry'
# email = 'hola@dojo.com'

username, email, lastname = 'henry', 'hola@dojo.com', 'vasquez'

print(username, email)


# for item in 'HENRY':
#     print(item)

# for item in (1, 'a', 3):
#     print(item)

# for item in {'user': 'pedro', 'id': 1}:
#     print(item)
