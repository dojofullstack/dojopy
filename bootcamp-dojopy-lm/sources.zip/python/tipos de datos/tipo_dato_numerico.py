
# tipo de dato numerico

mis_skills = 5
mis_skills_flot = 15.3

# print(mis_skills)
# print(type(mis_skills))

# print(dir(mis_skills))

# operator_suma = mis_skills + 10
# mis_skills = mis_skills + 10

# mis_skills += 10
# print(mis_skills)

# print(operator_suma)
# operator_resta = operator_suma - 1
# print(operator_resta)

# mis_skills = mis_skills * 5
# print(mis_skills)


# datos = '10'
# datos =  int(datos)
# print(datos)
# print(type(datos))
# print(type(mis_skills_flot))

print(mis_skills_flot/mis_skills)
print(mis_skills_flot//mis_skills)

print(round(mis_skills_flot//mis_skills))
