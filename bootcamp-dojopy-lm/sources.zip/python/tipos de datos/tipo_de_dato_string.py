
# esto es un comentario
""" esto es un comentario
muy extenso.."""
# tipo de dato string

programador = 'python python'
print(type(programador))

# print(dir(programador))

print(programador.upper())

print(programador.replace('py', '01'))

print(programador.count('py'))

mis_lenguajes = 2
mis_lenguajes = str(mis_lenguajes)

print(type(mis_lenguajes))