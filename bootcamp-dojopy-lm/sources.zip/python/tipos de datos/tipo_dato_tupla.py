
# tipo de dato tupla

elementos = ('python', 'javascript', 'c++')

print(elementos)
print(dir(elementos))