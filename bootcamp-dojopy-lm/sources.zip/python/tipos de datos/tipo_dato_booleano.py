
# tipo de dato booleano

soy_fullstack = True
no_soy_fullstack = False

# print(soy_fullstack)
# print(type(soy_fullstack))


# print(soy_fullstack == 1)
# print(no_soy_fullstack == 0)


print(bool({1,2,3}))