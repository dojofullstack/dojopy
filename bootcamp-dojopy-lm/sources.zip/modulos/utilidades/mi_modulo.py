import os
# import time
import datetime

def get_time():
    print('La hora actual es:', datetime.datetime.now())


def get_mes():
    print('El mes actual es:')


def open_software(name):
    os.system(name)
