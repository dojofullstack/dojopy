# import mi_modulo
from utilidades.mi_modulo import *

# modulo principal consulta

get_time()
get_mes()

# open_software('subl')
# open_software('firefox')