
# lectura y escritura de ficheros

# file_txt =  open('/home/henry/dojopy/bootcamp-dojopy-lm/input output/credenciales.txt')
# # print(dir(file_txt))
# data_plaintext = file_txt.read()
# print(data_plaintext)
# file_txt.close()


# with open('/home/henry/dojopy/bootcamp-dojopy-lm/input output/credenciales.txt', 'a') as file_txt:
#     # print(file_txt.read())
#     file_txt.write('\n pais=Perú')
#     print('se actualizo con exito')