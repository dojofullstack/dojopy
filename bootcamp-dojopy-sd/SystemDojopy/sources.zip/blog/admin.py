from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(BlogModel)
admin.site.register(BlogArticles)
admin.site.register(Tags)
admin.site.register(AdressBilling)
admin.site.register(ContactModel)