from django.shortcuts import render
from django.http import HttpResponse
from django.views import  View
from .models import *
from django.shortcuts import get_object_or_404

# Create your views here.

def home(request):
    if request.method == 'GET':
        return render(request, 'ecommerce/home_ecommerce.html', {})
    else:
        return JsonResponse({'data': 2, 'message': 'ok'})


class Blog(View):
    def get(self, request):
        data = BlogModel.objects.all().order_by('time_created')
        data = data[:10]

        return render(request, 'ecommerce/blog.html', {'obj_post': data})
    
    def post(self, request):
        return JsonResponse({'data': 1, 'message': 'ok'})


class BlogDetail(View):
    def get(self, request, slug):
        # data = BlogModel.objects.get(slug=slug)
        data = get_object_or_404(BlogModel, slug=slug)
        
        return render(request, 'ecommerce/blog_detail.html', {'post': data})
    
