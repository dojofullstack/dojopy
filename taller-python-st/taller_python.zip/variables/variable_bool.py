# variable bool

user_registrado = 0
user_not_register = False

print(user_registrado)
print(type(user_registrado))
print(user_not_register)
print(user_registrado + user_not_register)

# print(user_not_register == user_registrado)
# print(dir(user_registrado))
