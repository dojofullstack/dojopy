
# esta es una variable string
username = 'dojopy1'
print(username)
# print(dir(username))

print(username.upper())
print(username.title())
print(username.replace('dojo', 'stefany-'))
print(username.isalpha())
print(username.isalnum())
print(username.find('stefany'))
print(username.split('jo'))

variable_vacia = str()
print(variable_vacia)
# print(type(variable_vacia))

print(type(str(123)))

new_var =  str(123)
print(type(new_var))
