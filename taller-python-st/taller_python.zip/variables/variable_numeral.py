# variable numeral, compuesta enteros y los deciamales float

numero_aciertos = 10
print(numero_aciertos)
print(type(numero_aciertos))
# print(dir(numero_aciertos))

jugador = 1

# numero_aciertos = numero_aciertos + jugador
# numero_aciertos = numero_aciertos - jugador
# numero_aciertos = numero_aciertos * jugador
numero_aciertos = numero_aciertos / jugador

# numero_aciertos += jugador
# numero_aciertos -= jugador
# numero_aciertos /= jugador
# numero_aciertos *= jugador
# print(numero_aciertos)