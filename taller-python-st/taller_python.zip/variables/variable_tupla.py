# variable tupla

apikey = ('123456', 'avcbea2891bga2') #renic

print(apikey)
# print(type(apikey))
# print(dir(apikey))
print(apikey.count('0192019212'))
try:
    print(apikey.index('--avcbea2891bga2'))
except:
    print('este valor no existe :9')

print(len(apikey))